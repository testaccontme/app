// ignore_for_file: non_constant_identifier_names, dangling_library_doc_comments

///  =================================================================
/// ********************** BASE URL FOR API ********************
/// ==================================================================
///
String contactsupportEmail = "support@gmail.com";
String imgBaseurl = "https://vedicbhagya.in/";
String pdfBaseurl = "https://vedicbhagya.in/public";
String appMode = "LIVE";
String OtplessappId = "A57OBN9737HZYKHXRGK2";

String storiesIcon = "assets/images/stories_icon.png";

Map<String, dynamic> appParameters = {
  "LIVE": {
    "apiUrl": "https://vedicbhagya.in/api/",
  },
  "DEV": {
    "apiUrl": "https://vedicbhagya.in/api/",
  }
};
